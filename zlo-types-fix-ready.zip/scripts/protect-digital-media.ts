import type { SanitizedConfig } from "payload";
import { getPayload } from "payload";

function relationId(value: unknown): string | number | null {
  if (typeof value === "string" || typeof value === "number") {
    return value;
  }
  if (typeof value === "object" && value !== null && "id" in value) {
    const id = value.id;
    return typeof id === "string" || typeof id === "number" ? id : null;
  }
  return null;
}

// IMPORTANT: The `payload run` command looks for a named `script` export.
// Merely exporting or calling a `main()` function does not implement this contract.
export const script = async (config: SanitizedConfig) => {
  const payload = await getPayload({ config });
  console.log("Scanning digital artwork originals...");

  const ids = new Set<number>();
  let page = 1;
  let hasNextPage = true;

  while (hasNextPage) {
    const result = await payload.find({
      collection: "artworks",
      depth: 0,
      limit: 100,
      page,
      overrideAccess: true,
    });

    for (const artwork of result.docs) {
      if (artwork.type !== "digital") continue;
      const rawId = relationId(artwork.digitalFile);
      const mediaId = Number(rawId);
      if (rawId !== null && Number.isSafeInteger(mediaId) && mediaId > 0) {
        ids.add(mediaId);
      }
    }

    hasNextPage = result.hasNextPage;
    page += 1;
  }

  let changed = 0;

  for (const id of ids) {
    const media = await payload.findByID({
      collection: "media",
      id,
      depth: 0,
      overrideAccess: true,
    });

    if (media.isProtected !== true) {
      await payload.update({
        collection: "media",
        id,
        data: { isProtected: true },
        depth: 0,
        overrideAccess: true,
      });
      changed += 1;
    }
  }

  console.log(
    `Protected ${changed} existing digital originals. Total referenced originals: ${ids.size}.`
  );
  console.log("Migration finished successfully.");

  // Payload owns persistent DB connections. For a one-off CLI task, finish explicitly.
  process.exit(0);
};
