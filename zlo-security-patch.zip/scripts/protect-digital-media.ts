import { getPayload } from "payload";
import config from "../src/payload.config.ts";

function relationId(value: unknown): string | number | null {
  if (typeof value === "string" || typeof value === "number") {
    return value;
  }

  if (typeof value === "object" && value !== null && "id" in value) {
    const id = value.id;
    if (typeof id === "string" || typeof id === "number") {
      return id;
    }
  }

  return null;
}

async function main() {
  const payload = await getPayload({ config });
  const ids = new Set<string>();

  let page = 1;
  let hasNextPage = true;

  while (hasNextPage) {
    const result = await payload.find({
      collection: "artworks",
      depth: 0,
      limit: 100,
      page,
      overrideAccess: true,
    });

    for (const artwork of result.docs) {
      if (artwork.type !== "digital") {
        continue;
      }

      const id = relationId(artwork.digitalFile);
      if (id !== null) {
        ids.add(String(id));
      }
    }

    hasNextPage = result.hasNextPage;
    page += 1;
  }

  let changed = 0;

  for (const id of ids) {
    const numeric = Number(id);
    const payloadId = Number.isSafeInteger(numeric) ? numeric : id;

    const media = await payload.findByID({
      collection: "media",
      id: payloadId,
      depth: 0,
      overrideAccess: true,
    });

    if (media.isProtected !== true) {
      await payload.update({
        collection: "media",
        id: payloadId,
        data: { isProtected: true },
        depth: 0,
        overrideAccess: true,
      });
      changed += 1;
    }
  }

  console.log(
    `Protected ${changed} existing digital originals. Total referenced originals: ${ids.size}.`
  );
  console.log("Migration finished successfully.");
  process.exit(0);
}

main().catch((error) => {
  console.error("Migration failed:", error);
  process.exitCode = 1;
});
